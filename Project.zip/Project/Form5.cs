﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;

namespace Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll", EntryPoint = "mciSendStringA", ExactSpelling = true, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern int record(string ipstrCommand, string ipstrReturnString, int uReturnLenth, int hwndCallback);

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void StopBox_Click(object sender, EventArgs e)
        {
            var save = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            save += @"\mic.wav";
            record("save recsound " + save, "", 0, 0);
            record("close recsound", "", 0, 0);
            timer1.Stop();
            count.Stop();
            lblRecord.Text = "Recorded";
        }

        private void RecordBox_Click(object sender, EventArgs e)
        {
            record("open new Type waveaudio Alias recSound", "", 0, 0);
            record("record recsound", "", 0, 0);
            timer1.Start();
            count.Start();
            lblRecord.Text = "Rec...";
        }

        private void PlayBox_Click(object sender, EventArgs e)
        {

            var save = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            save += @"\mic.wav";
            (new Microsoft.VisualBasic.Devices.Audio()).Play(save);
            timer1.Start();
            count.Reset();
            count.Start();
            lblRecord.Text = "Playing..";
        }
        System.Diagnostics.Stopwatch count = new System.Diagnostics.Stopwatch();
        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan elapsed = count.Elapsed;
            lbl_timer.Text = string.Format("{0:00}:{1:00}:{2:00}", Math.Floor(elapsed.TotalHours), elapsed.Minutes, elapsed.Seconds);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            this.Hide();
            obj.Show();
        }
    }
}
