﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = "asfa_abbasi";
            pass = "ASFA";

            if ((textBox1.Text == user) && (textBox2.Text == pass))
            {
                MessageBox.Show("Login Successful");
                Form2 obj = new Form2();
                this.Hide();
                obj.Show();

            }
            else if ((textBox1.Text != user) && (textBox2.Text != pass))
            {
                MessageBox.Show("Invalid User");
                this.Close();
            }
            else if ((textBox1.Text != user) || (textBox2.Text == pass))
            {
                MessageBox.Show("Enter Valid Credentials");
                this.Close();
            }
            else
            {
                MessageBox.Show("Error!!!");
                this.Close();
            }
        }
    }
}
